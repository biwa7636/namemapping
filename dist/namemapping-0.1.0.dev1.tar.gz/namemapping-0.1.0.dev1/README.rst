namemapping

====================================
This is a Python library used to map company names to its company website 

